 # Hospital-Chatbot
A chatbot system targetted towards use in a hospital for administrative tasks.



### Note: 
The wiki page contains the basic information of this project.
* Weekly Reports 
* Progress Report
* Mid Evaluation Report ([link](https://github.com/adbcode/Hospital-Chatbot/wiki/Mid-Evaluation-Report))
* Final Report ([link](https://github.com/adbcode/Hospital-Chatbot/wiki/Final-Report))
